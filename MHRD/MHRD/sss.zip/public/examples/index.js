  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyDGlyf7qAf95chsy5OR7ogYrkj01DUKlsM",
    authDomain: "survey-7f227.firebaseapp.com",
    databaseURL: "https://survey-7f227.firebaseio.com",
    projectId: "survey-7f227",
    storageBucket: "survey-7f227.appspot.com",
    messagingSenderId: "1051121084304",
    appId: "1:1051121084304:web:4186cf16c951be99"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  function signoutUser(){
   firebase.auth().signOut().then(function() {
    window.location.replace("./login.html");
    localStorage.setItem('id',id);
}).catch(function(error) {
  var errorCode=error.code;
    var errorMsg=error.message;
});
  }


function see_table_body(){
    var rootref=firebase.database().ref().child('forms');
    
    rootref.on('child_added',snap=>{
    var entry_by=snap.child('agentname').val();
    var locality=snap.child('headoffamily').child('nameofslum').val();
    var hof=snap.child('headoffamily').child('headoffamily').val();
    var gender=snap.child('headoffamily').child('gender').val();
    var cat=snap.child('headoffamily').child('category').val();
    var religion=snap.child('headoffamily').child('religion').val();
    var nationality=snap.child('headoffamily').child('nationality').val();
    var ano=snap.child('headoffamily').child('aadhar').val();
    // document.getElementById('fname').innerHTML=fname;
    // document.getElementById('age').innerHTML=age;
      var table=document.getElementById('table_body');
      var newrow=table.insertRow(0);
      var ce1=newrow.insertCell(0);
      var ce2=newrow.insertCell(1);
      var ce3=newrow.insertCell(2);
      var ce4=newrow.insertCell(3);
      var ce5=newrow.insertCell(4);
      var ce6=newrow.insertCell(5);
      var ce7=newrow.insertCell(6);
      var ce8=newrow.insertCell(7);
      var ce9=newrow.insertCell(8);
      ce1.innerHTML=entry_by;
      ce2.innerHTML=locality;
      ce3.innerHTML=hof;
      ce4.innerHTML=gender;
      ce5.innerHTML=cat;
      ce6.innerHTML=religion;
      ce7.innerHTML=nationality;
      ce8.innerHTML=ano;
      ce9.innerHTML="<button id='delbtn' type='button' class='btn btn-sm yesbtn' background-color='#4CAF50'  onclick=SeeUser('"+snap.key+"')>See Entry</button>";
    });
    
    function SeeUser(key) {
      window.alert(key);
      
  
      window.location('./showentry.html');
  
  }
}

function see_detail_table(){
    function seeTable1() {
    var rootref=firebase.database().ref().child('forms');
      rootref.on('child_added',snap=>{
      var headoffamily=snap.child('value').child('headoffamily').child('headoffamily').val();             //The value used here is the referrence to the key passed. Key passing left
      var aadhar=snap.child('value').child('headoffamily').child('aadhar').val();
      var address=snap.child('value').child('headoffamily').child('address').val();
      var category=snap.child('value').child('headoffamily').child('category').val();
      var gender=snap.child('value').child('headoffamily').child('gender').val();
      var familyincome=snap.child('value').child('headoffamily').child('familyincome').val();
      var fathername=snap.child('value').child('headoffamily').child('fathername').val();
      var hofage=snap.child('value').child('headoffamily').child('hofage').valhofage
      var religion=snap.child('value').child('headoffamily').child('religion').val();
      var nationality=snap.child('value').child('headoffamily').child('nationality').val();
      var ano=snap.child('value').child('headoffamily').child('aadhar').val();
      var mob=snap.child('value').child('headoffamily').child('mob').val();
      var nameofslum=snap.child('value').child('headoffamily').child('nameofslum').val();
      var numberofmembers=snap.child('value').child('headoffamily').child('numberofmembers').val();
      // document.getElementById('fname').innerHTML=fname;
      // document.getElementById('age').innerHTML=age;
        var table=document.getElementById('hof_table');
        var newrow=table.insertRow(0);
        var ce1=newrow.insertCell(0);
        var ce2=newrow.insertCell(1);
        var ce3=newrow.insertCell(2);
        var ce4=newrow.insertCell(3);
        var ce5=newrow.insertCell(4);
        var ce6=newrow.insertCell(5);
        var ce7=newrow.insertCell(6);
        var ce8=newrow.insertCell(7);
        var ce9=newrow.insertCell(8);
        var ce10=newrow.insertCell(9);
        var ce11=newrow.insertCell(10);
        var ce12=newrow.insertCell(11);
        var ce13=newrow.insertCell(12);
        var ce14=newrow.insertCell(13);
        ce1.innerHTML=headoffamily;
        ce2.innerHTML=aadhar;
        ce3.innerHTML=address;
        ce4.innerHTML=category;
        ce5.innerHTML=gender;
        ce6.innerHTML=familyincome;
        ce7.innerHTML=fathername;
        ce8.innerHTML=hofage;
        ce9.innerHTML=religion;
        ce10.innerHTML=nationality;
        ce11.innerHTML=ano;
        ce12.innerHTML=mob;
        ce13.innerHTML=nameofslum;
        ce14.innerHTML=numberofmembers;
      });
      }
    
    function seeTable2(key) {
        var rootref=firebase.database().ref().child('forms');
        
      rootref.on('child_added',snap=>{
        var area=snap.child('houseoffamily').child('area').val();          //This value used here is the reference to the key. Key passing left
        var areabuilt=snap.child('houseoffamily').child('areabuilt').val();
        var conhouse=snap.child('houseoffamily').child('conhouse').val();
        var consent=snap.child('houseoffamily').child('consent').val();
        var kitchen=snap.child('houseoffamily').child('kitchen').val();
        var room=snap.child('houseoffamily').child('room').val();
        var toilet=snap.child('houseoffamily').child('toilet').val();
        var yearsofstaying=snap.child('houseoffamily').child('yearsofstaying').val();
      // document.getElementById('fname').innerHTML=fname;
      // document.getElementById('age').innerHTML=age;
        var table=document.getElementById('house_table');
        var newrow=table.insertRow(0);
        var ce1=newrow.insertCell(0);
        var ce2=newrow.insertCell(1);
        var ce3=newrow.insertCell(2);
        var ce4=newrow.insertCell(3);
        var ce5=newrow.insertCell(4);
        var ce6=newrow.insertCell(5);
        var ce7=newrow.insertCell(6);
        var ce8=newrow.insertCell(7);
        var ce9=newrow.insertCell(8);
        ce1.innerHTML=area;
        ce2.innerHTML=areabuilt;
        ce3.innerHTML=conhouse;
        ce4.innerHTML=consent;
        ce5.innerHTML=kitchen;
        ce6.innerHTML=room;
        ce7.innerHTML=toilet;
        ce8.innerHTML=yearsofstaying;
      });
      }
  
    function seeTable3() {              // This is the key that is received from the see entry part of the previous page.
        var rootref=firebase.database().ref().child('forms').child('members');
        
      rootref.on('child_added',snap=>{
        var secref=snap.child('members');
        secref.on('child_added', snapshot=>{
          var nameofmember=snap.child('nameofmember').val();
          var aahar=snapshot.child('aahar').val();
          var age=snapshot.child('age').val();        //TODO:Loop for iterating all members left and key passing left.
          var gender=snapshot.child('gender').val();
          var relation=snapshot.child('relation').val();
          // document.getElementById('fname').innerHTML=fname;
          // document.getElementById('age').innerHTML=age;
            var table=document.getElementById('member_table');
            var newrow=table.insertRow(0);
            var ce1=newrow.insertCell(0);
            var ce2=newrow.insertCell(1);
            var ce3=newrow.insertCell(2);
            var ce4=newrow.insertCell(3);
            var ce5=newrow.insertCell(4);
            ce1.innerHTML=nameofmember;
            ce2.innerHTML=aahar;
            ce3.innerHTML=age;
            ce4.innerHTML=gender;
            ce5.innerHTML=relation;shot
        })
      });
      }
}