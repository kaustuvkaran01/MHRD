from flask import Flask, render_template, request
 
app = Flask(__name__)
 
@app.route('/')
@app.route('/hello')
@app.route('/hello/parth')
def hello_world(user=None):
    user = user or 'Parth'
    return render_template('untitled.html', user=user)