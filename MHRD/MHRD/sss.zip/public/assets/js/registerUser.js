(function() {
    //Initialize Firebase
    const config = {
        apiKey:"AIzaSyDunR_Iq4naOoK1EpU6CkIlvq0K6NgfqlI",
        authDomain:"survey-7f227.firebaseapp.com",                                //TODO: Check this before running.
        databseURL:"https://survey-7f227.firebaseio.com",                         //TODO: Firebase files are missing. Import them.
        storageBucket:"survey-7f227.appspot.com",
    };


    firebase.initializeApp(config);
    db = firebase.database();

//TODO: These are the first list of errors.
/*GET file:///F:/MHRD/MyWebsite/public/argon-dashboard-master/assets/js/plugins/nucleo/css/nucleo.css net::ERR_FILE_NOT_FOUND
login.html:138 GET file:///F:/MHRD/MyWebsite/public/argon-dashboard-master/assets/js/plugins/jquery/dist/jquery.min.js net::ERR_FILE_NOT_FOUND
login.html:139 GET file:///F:/MHRD/MyWebsite/public/argon-dashboard-master/assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js net::ERR_FILE_NOT_FOUND
login.html:156 GET file:///F:/__/firebase/6.3.5/firebase-app.js net::ERR_FILE_NOT_FOUND
login.html:159 GET file:///F:/__/firebase/6.3.5/firebase-auth.js net::ERR_FILE_NOT_FOUND
login.html:160 GET file:///F:/__/firebase/6.3.5/firebase-firestore.js net::ERR_FILE_NOT_FOUND
login.html:161 GET file:///F:/__/firebase/init.js net::ERR_FILE_NOT_FOUND
argon-dashboard.min.js?v=1.1.0:19 Uncaught ReferenceError: $ is not defined
    at argon-dashboard.min.js?v=1.1.0:19
    at argon-dashboard.min.js?v=1.1.0:19
registerUser.js:11 Uncaught ReferenceError: firebase is not defined
    at registerUser.js:11
    at registerUser.js:57
(anonymous)	@	registerUser.js:11
(anonymous)	@	registerUser.js:57
*/
//Get elements
const txtEmail = document.getElementById('txtEmail');
const txtPassword = document.getElementById('txtPassword');
const btnLogin = document.getElementById('btnLogin');
const btnSignUp = document.getElementById('btnSignUp');
const btnLogout = document.getElementById('btnLogout');

//Add Login Event
btnLogin.addEventListener('click',e =>{
    //Get email and password
    const email = txtEmail.value;
    const pass = txtPassword.value;
    const auth = firebase.auth();
    //Sign In
   const promise =  auth.signInWithEmailAndPassword(email,pass);
   promise.catch(e => console.log(e.message));
});
btnSignUp.addEventListener('click', e=>{
        //Get email and password
        //TODO: CHECK 4 REAL EMAILZ
        const email = txtEmail.value;
        const pass = txtPassword.value;
        const auth = firebase.auth();
        //Sign Up
       const promise =  auth.createUserWithEmailAndPassword(email,pass);
       promise
        .catch(e => console.log(e.message));
})


btnLogout.addEventListener('click', e => {
    firebase.auth.signOut();
});


//Add a realtime listener
firebase.auth().onAuthStateChanged(firebaseUser=> {
    if(firebaseUser){
        console.log(firebaseUser);
    } else {
        console.log('not logged in ');
    }
})

//Fetching the data from the database
var ref = db.ref('forms');
ref.on('value',gotData,errData);
function gotData(data) {
    console.log(data.val());
}
function errData(err) {
    console.log('error!');
    console.log(err);
}

var rootRef = db.ref().chid("forms").child("12aLavZD0neRGIJTeIc8pLX2Iri1").chid("434114767").child("headoffamily");
rootRef.on("child_changed", snap =>{
    var name = snap.child("headoffamily").val();
    var Fname = snap.child("fathername").val();


    $("#table_body").append("<tr><td>" + name + "</td><td>" + Fname + "</td></tr>");
})

}());