package com.example.slumsurvey;

public class membersformcl {
    private String Nameofmember,gender,age,relation,aahar ;

    public membersformcl(String nameofmember, String gender, String age, String relation, String aahar) {
        Nameofmember = nameofmember;
        this.gender = gender;
        this.age = age;
        this.relation = relation;
        this.aahar = aahar;
    }

    /*public String getNameofmember() {
        return Nameofmember;
    }

    public void setNameofmember(String nameofmember) {
        Nameofmember = nameofmember;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getAahar() {
        return aahar;
    }

    public void setAahar(String aahar) {
        this.aahar = aahar;
    }*/

    public String getNameofmember() {
        return Nameofmember;
    }

    public String getGender() {
        return gender;
    }

    public String getAge() {
        return age;
    }

    public String getRelation() {
        return relation;
    }

    public String getAahar() {
        return aahar;
    }

    public void setNameofmember(String nameofmember) {
        Nameofmember = nameofmember;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public void setAahar(String aahar) {
        this.aahar = aahar;
    }
}
